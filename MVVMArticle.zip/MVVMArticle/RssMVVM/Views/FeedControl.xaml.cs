﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="FeedControl.xaml.cs" company="Reed Copsey, Jr.">
//   Copyright 2009, Reed Copsey, Jr.
// </copyright>
// --------------------------------------------------------------------------------------------------------------------
namespace RssMVVM.Views
{
    /// <summary>
    /// Interaction logic for UserControl1.xaml
    /// </summary>
    public partial class FeedControl
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="FeedControl"/> class.
        /// </summary>
        public FeedControl()
        {
            InitializeComponent();
        }
    }
}
