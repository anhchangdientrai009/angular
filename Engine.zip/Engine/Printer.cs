﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Drawing.Imaging;
using System.Drawing.Printing;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Reporting.WinForms;

namespace NOBEL.Reports.Engine
{    
    public class Printer : IDisposable
    {
        private int _currentPageIndex;
        private IList<Stream> _streams;
        private PrintDocument _printDoc;
        
        // Routine to provide to the report renderer, in order to
        // save an image for each page of the report.
        private Stream CreateStream(string name, string fileNameExtension, Encoding encoding, string mimeType, bool willSeek)
        {
            Stream stream = new MemoryStream();
            _streams.Add(stream);
            return stream;
        }
        private string GetPaperSetting(ReportSetting reportSetting)
        {
            string deviceInfo = @"<DeviceInfo>
                                    <OutputFormat>EMF</OutputFormat>
                                    <PageWidth>www</PageWidth>
                                    <PageHeight>hhh</PageHeight>                                    
                                     </DeviceInfo>";

            return deviceInfo = reportSetting.IsLandscape ? deviceInfo.Replace("www", "29.7cm").Replace("hhh", "21cm") : deviceInfo.Replace("www", "21cm").Replace("hhh", "29.7cm");            
        }

        // Export the given report as an EMF (Enhanced Metafile) file.
        private void Export(LocalReport report, ReportSetting reportSetting)
        {
            var deviceInfo = GetPaperSetting(reportSetting);

            Warning[] warnings;
            _streams = new List<Stream>();
            report.Render("Image", deviceInfo, CreateStream, out warnings);
            foreach (Stream stream in _streams)
                stream.Position = 0;
        }
        // Handler for PrintPageEvents
        private void PrintPage(object sender, PrintPageEventArgs ev)
        {
            Metafile pageImage = new Metafile(_streams[_currentPageIndex]);

            // Adjust rectangular area with printer margins.
            Rectangle adjustedRect = new Rectangle(
                ev.PageBounds.Left - (int)ev.PageSettings.HardMarginX,
                ev.PageBounds.Top - (int)ev.PageSettings.HardMarginY,
                ev.PageBounds.Width,
                ev.PageBounds.Height);

            // Draw a white background for the report
            ev.Graphics.FillRectangle(Brushes.White, adjustedRect);

            // Draw the report content
            ev.Graphics.DrawImage(pageImage, adjustedRect);

            // Prepare for the next page. Make sure we haven't hit the end.
            _currentPageIndex++;
            ev.HasMorePages = (_currentPageIndex < _streams.Count);
        }

        private void Print()
        {
            if (_streams == null || _streams.Count == 0)
                throw new Exception("Error: no stream to print.");

            using (_printDoc)
            {
                if (_printDoc.PrinterSettings.IsValid)
                {
                    _printDoc.PrintPage += new PrintPageEventHandler(PrintPage);
                    _currentPageIndex = 0;
                    try
                    {
                        _printDoc.Print();
                    }
                    catch(Exception)
                    {
                        throw;
                    }                    
                }
                else
                {
                    throw new Exception("Error: cannot find the default printer.");
                }
            }
        }

        private bool PrinterSetting(ReportSetting reportSetting)
        {
            using (PrintDialog printDialog = new PrintDialog())
            {
                _printDoc = new PrintDocument
                {
                    PrinterSettings =
                    {
                        Collate = true,
                        Copies = 1,
                        FromPage = 1,
                        ToPage = 1,
                        DefaultPageSettings =
                        {
                            Landscape = reportSetting.IsLandscape
                        }
                    }
                };

                IEnumerable<PaperSize> paperSizes = _printDoc.PrinterSettings.PaperSizes.Cast<PaperSize>();
                PaperSize paperSize = paperSizes.First(size => size.Kind == reportSetting.PaperKind);
                _printDoc.PrinterSettings.DefaultPageSettings.PaperSize = paperSize;

                //Set PrinterSettings from print dialog box to Print Document
                printDialog.PrinterSettings = _printDoc.PrinterSettings;                
                printDialog.UseEXDialog = true;
                if (printDialog.ShowDialog() == DialogResult.Cancel)
                {
                    return false;
                }
                else
                {
                    _printDoc.PrinterSettings = printDialog.PrinterSettings;
                    _printDoc.PrinterSettings.Duplex = printDialog.PrinterSettings.Duplex;
                    return true;
                }
            }                            
        }

        // Create a local report for Report.rdlc, load the data,
        // export the report to an .emf file, and print it.
        public bool Print(string reportName, DataTable dataTable, ReportSetting reportSetting)
        {
            var isPrint = PrinterSetting(reportSetting);

            if (!isPrint)
                return false;

            if (_printDoc.PrinterSettings.IsValid || _printDoc.PrinterSettings.IsDefaultPrinter)
            {
                LocalReport report = new LocalReport();
                report.ReportEmbeddedResource = $"{typeof(Printer).Assembly.GetName().Name}.Reports.{reportName}.rdlc";
                report.DataSources.Add(new ReportDataSource("ReportTitles", dataTable));
                Export(report, reportSetting);
                Print();
            }

            return true;           
        }        

        //Load a local report to display in ReportViewer.
        public ReportViewer Render(string reportName, DataTable dataTable)
        {
            ReportViewer reportViewer = new ReportViewer();
            var dataSource = new ReportDataSource("ReportTitles", dataTable);
            reportViewer.LocalReport.DataSources.Clear();
            reportViewer.LocalReport.DataSources.Add(dataSource);
            reportViewer.LocalReport.ReportEmbeddedResource = $"{typeof(Printer).Assembly.GetName().Name}.Reports.{reportName}.rdlc";
            reportViewer.RenderingComplete += ReportViewer_RenderingComplete;
            reportViewer.ZoomMode = ZoomMode.Percent;
            //reportViewer.RefreshReport();
            return reportViewer;
        }

        private void ReportViewer_RenderingComplete(object sender, RenderingCompleteEventArgs e)
        {
            ReportViewer reportViewer = (sender as ReportViewer);
            reportViewer.RenderingComplete -= ReportViewer_RenderingComplete;
            reportViewer.SetDisplayMode(DisplayMode.PrintLayout);
        }

        public void Dispose()
        {
            if (_streams != null)
            {
                foreach (Stream stream in _streams)
                    stream.Close();
                _streams = null;
            }
        }        
    }
}