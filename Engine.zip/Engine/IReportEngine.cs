﻿using Microsoft.Reporting.WinForms;
using System.Collections.Generic;

namespace NOBEL.Reports.Engine
{
    public interface IReportEngine<in TViewModel>
    {
        bool Print(TViewModel viewModel, BeforePrintingContext context = null, IDictionary<string, string> localizedData = null);
        ReportViewer Render(TViewModel viewModel);
    }
}
