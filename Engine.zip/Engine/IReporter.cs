﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NOBEL.Reports.Engine
{
    public interface IReporter
    {
        string ReportName { get; }        
        DataTable Data { get; }
        ReportSetting ReportSetting { get; }
        bool CanReport(Type type, Func<dynamic> func);
    }
}
