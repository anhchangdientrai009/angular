﻿using Neodynamic.WPF;
using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing.Printing;
using System.Windows.Media;

namespace NOBEL.Reports.Engine
{
    public abstract  class ReportBinder<TViewModel> : IReporter
    {        
        public ReportBinder()
        {
            ReportSetting = new ReportSetting
            {
                PaperKind = PaperKind.A4
            };
        }
        public ReportSetting ReportSetting { get; protected set; }
        public abstract string ReportName { get; }
        public DataTable Data { get; protected set; }
        protected string ImagePath => "..\\..\\Resources\\images\\";
        public virtual bool CanReport(Type type, Func<dynamic> func)
        {
            return type == typeof(TViewModel);
        }                
        protected virtual void Initialze()
        {
            const int numberOfTitles = 75;
            const int numberOfData = 75;
            const int numberOfImages = 10;

            Data = new DataTable();

            for (int i = 1; i <= numberOfTitles; i++)
            {
                Data.Columns.Add($"Title{i}", typeof(string));
            }

            for (int i = 1; i <= numberOfData; i++)
            {
                Data.Columns.Add($"Data{i}", typeof(string));
            }

            for (int i = 1; i <= numberOfImages; i++)
            {
                Data.Columns.Add($"Image{i}", typeof(byte[]));
            }
        }                
        protected void Reset()
        {
            Data = null;
        }       
        protected byte[] GetBarcodePdf417(string code, bool displayCode = false)
        {
            var barcode = GetBarcodeProfessional();
            barcode.Symbology = Symbology.Pdf417;
            barcode.CodabarStartChar = CodabarStartStopChar.A;
            barcode.CodabarStopChar = CodabarStartStopChar.A;
            barcode.Code = code;
            barcode.DisplayCode = displayCode;

            return barcode.GetBarcodeImageBinary();
        }

        protected byte[] GetBarcodeDataMatrix(string code, bool displayCode = false)
        {
            var barcode = GetBarcodeProfessional();
            barcode.Symbology = Symbology.DataMatrix;
            barcode.CodabarStartChar = CodabarStartStopChar.A;
            barcode.CodabarStopChar = CodabarStartStopChar.A;
            barcode.Code = code;
            barcode.DisplayCode = displayCode;

            return barcode.GetBarcodeImageBinary();
        }

        protected byte[] GetBarcode39(string code, bool displayCode = false)
        {
            var barcode = GetBarcodeProfessional();
            barcode.Symbology = Symbology.Code39;
            barcode.CodabarStartChar = CodabarStartStopChar.A;
            barcode.CodabarStopChar = CodabarStartStopChar.B;
            barcode.Code = code;
            barcode.DisplayCode = displayCode;            

            return barcode.GetBarcodeImageBinary();
        }

        protected byte[] GetBarcode128(string code, bool displayCode = false)
        {
            var barcode = GetBarcodeProfessional();
            barcode.Symbology = Symbology.Code128;
            barcode.CodabarStartChar = CodabarStartStopChar.A;
            barcode.CodabarStopChar = CodabarStartStopChar.B;
            barcode.Code = code;
            barcode.DisplayCode = displayCode;

            return barcode.GetBarcodeImageBinary();
        }

        protected BarcodeProfessional GetBarcodeProfessional()
        {
            BarcodeProfessional barcode = new BarcodeProfessional();
            barcode.Width = 300;
            barcode.Height = 200;
            barcode.Code128CharSet = Code128.Auto;            
            barcode.Pdf417Truncated = false;
            barcode.Pdf417ErrorCorrectionLevel = Pdf417ErrorCorrection.Level0;
            barcode.QRCodeErrorCorrectionLevel = QRCodeErrorCorrectionLevel.L;
            barcode.FontFamily = new FontFamily("Verdana");
            barcode.FontSize = 8;
            barcode.FontUnit = FontUnit.Point;
            barcode.TextFontFamily = new FontFamily("Arial");
            barcode.TextFontSize = 8;
            barcode.TextFontUnit = FontUnit.Point;                        
            barcode.ImageSettings.Dpi = 96;
            barcode.AddChecksum = false;

            return barcode;
        }

        protected abstract void BindData(TViewModel viewModel, IDictionary<string, string> localizedData);
        public void BindeDataCore(TViewModel viewModel, IDictionary<string, string> localizedData)
        {
            Reset();
            Initialze();
            BindData(viewModel, localizedData);
        }
        protected void BindLabels(DataRow dataRow, IDictionary<string, string> localizedData)
        {
            foreach (var key in localizedData.Keys)
            {
                dataRow[key] = localizedData[key];
            }
        }
    }
}
