﻿using System;
using System.Collections.Generic;
using System.Drawing.Printing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NOBEL.Reports.Engine
{
    public class ReportSetting
    {
        public bool IsLandscape { get; set; }
        public PaperKind PaperKind { get; set; }
    }    
}
