﻿using Microsoft.Reporting.WinForms;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Reflection;

namespace NOBEL.Reports.Engine
{
    public class ReportEngine<TViewModel> : IReportEngine<TViewModel>
    {        
        readonly IEnumerable<IReporter> _reporters;
        public ReportEngine(IEnumerable<IReporter> reporters)
        {            
            _reporters = reporters;
        }
        
        protected void EnsureValidation(TViewModel viewModel, Func<dynamic> func)
        {
            if (viewModel == null)
            {
                throw new ArgumentNullException();
            }            
            
            if (_reporters.All(x => !x.CanReport(viewModel.GetType(), func)))
            {
                throw new InvalidOperationException($"Not specific reporter for this type: {viewModel.GetType()} ");
            }
        }
        
        protected IReporter GetReporter(Type viewModelType, Func<dynamic> func)
        {
            return _reporters.Where(x => x.CanReport(viewModelType, func)).FirstOrDefault();
        }

        protected DataTable GetDataTable(IReporter reporter, TViewModel viewModel, IDictionary<string, string> localizedData = null)
        {
            //DataTable dataTable = (reporter as ReportConverter<TViewModel>).Convert(viewModel);            
            MethodInfo method = reporter.GetType().GetMethod("BindeDataCore");
            method.Invoke(reporter, new object[] { viewModel, localizedData });

            return reporter.Data;            
        }
        public bool Print(TViewModel viewModel, BeforePrintingContext context, IDictionary<string, string> localizedData)
        {
            EnsureValidation(viewModel, context.Func);
            
            IReporter reporter = GetReporter(viewModel.GetType(), context.Func);
            DataTable dataTable = GetDataTable(reporter, viewModel, localizedData);

            using (Printer report = new Printer())
            {
                return report.Print(reporter.ReportName, dataTable, reporter.ReportSetting);
            }
        }

        public ReportViewer Render(TViewModel viewModel)
        {
            EnsureValidation(viewModel, null);
            
            IReporter reporter = GetReporter(viewModel.GetType(), null);
            DataTable dataTable = GetDataTable(reporter, viewModel);

            using (Printer report = new Printer())
            {
                return report.Render(reporter.ReportName, dataTable);                
            }
        }
    }
}
