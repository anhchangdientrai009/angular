﻿using NOBEL.Reports.Engine;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NOBEL.Reports.Engine
{
    public interface IActionHookPrinting
    {        
        void OnBeforePrinting(BeforePrintingContext context);
        void OnAfterPrinting(AfterPrintingContext context);
    }
}
