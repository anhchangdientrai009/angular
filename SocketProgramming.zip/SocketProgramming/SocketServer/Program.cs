﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SocketServer
{
    class Program
    {
        //https://codereview.stackexchange.com/questions/19850/c-async-socket-server-with-events
        static void Main(string[] args)
        {
            AsynchronousSocketListener.StartListening();
            Console.ReadLine();
        }
    }
}
