﻿using System;

namespace SmartCA.DataContracts
{
    public enum PriceChangeTypeContract
    {
        ContractSum,
        GuaranteedMaximumPrice
    }
}
