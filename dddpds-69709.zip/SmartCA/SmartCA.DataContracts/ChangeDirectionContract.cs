﻿using System;

namespace SmartCA.DataContracts
{
    public enum ChangeDirectionContract
    {
        Increased,
        Decreased,
        Unchanged
    }
}
