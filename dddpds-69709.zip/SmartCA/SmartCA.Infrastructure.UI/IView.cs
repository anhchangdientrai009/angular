﻿using System;

namespace SmartCA.Infrastructure.UI
{
    public interface IView
    {
        void Show();
        void Close();
    }
}
