﻿using SmartCA.Infrastructure.DomainBase;

namespace SmartCA.UnitTests.Mocks
{
    public class MockRuleMessages : BrokenRuleMessages
    {
        protected override void PopulateMessages()
        {
        }
    }
}
