﻿using System;

namespace SmartCA.Infrastructure.Transactions
{
    public enum TransactionType
    {
        Insert,
        Update,
        Delete
    }
}
