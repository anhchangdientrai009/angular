﻿using System;

namespace SmartCA.Infrastructure.DomainBase
{
    public interface IEntity
    {
        object Key { get; }
    }
}
