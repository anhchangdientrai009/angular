﻿using System;

namespace SmartCA.Model.Description
{
    internal static class DescriptionRuleMessageKeys
    {
        public const string InvalidDescription = 
            "Invalid Description property value";
    }
}
