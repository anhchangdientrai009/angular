﻿using System;

namespace SmartCA.Model.Description
{
    public interface IDescribable
    {
        string Description { get; set; }
    }
}
