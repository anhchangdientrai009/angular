﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SmartCA.Model
{
    public class OfficeLocation
    {
    }
}
