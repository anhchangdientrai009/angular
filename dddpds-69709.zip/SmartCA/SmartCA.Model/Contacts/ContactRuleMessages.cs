﻿using System;
using SmartCA.Infrastructure.DomainBase;

namespace SmartCA.Model.Contacts
{
    public class ContactRuleMessages : BrokenRuleMessages
    {
        protected override void PopulateMessages()
        {
        }
    }
}
