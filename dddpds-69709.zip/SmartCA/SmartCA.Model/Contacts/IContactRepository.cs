﻿using System;
using SmartCA.Infrastructure.RepositoryFramework;

namespace SmartCA.Model.Contacts
{
    public interface IContactRepository : IRepository<Contact>
    {
    }
}
