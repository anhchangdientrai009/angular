﻿using System;

namespace SmartCA.Model.Membership
{
    public enum PasswordFormat
    {
        Clear = 0,
        Hashed = 1
    }
}
