﻿using System;
using SmartCA.Infrastructure.DomainBase;

namespace SmartCA.Model.Projects
{
    public class ProjectRuleMessages : BrokenRuleMessages
    {
        protected override void PopulateMessages()
        {
        }
    }
}
