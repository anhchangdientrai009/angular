﻿using System;
using SmartCA.Infrastructure.DomainBase;

namespace SmartCA.Model.Submittals
{
    public class SubmittalRuleMessages : BrokenRuleMessages
    {
        protected override void PopulateMessages()
        {
        }
    }
}
