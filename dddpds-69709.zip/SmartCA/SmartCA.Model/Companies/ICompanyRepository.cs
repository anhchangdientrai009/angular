﻿using System;
using SmartCA.Infrastructure.RepositoryFramework;

namespace SmartCA.Model.Companies
{
    public interface ICompanyRepository : IRepository<Company>
    {
    }
}
