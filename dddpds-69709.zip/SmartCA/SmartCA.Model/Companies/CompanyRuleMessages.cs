﻿using System;
using SmartCA.Infrastructure.DomainBase;

namespace SmartCA.Model.Companies
{
    public class CompanyRuleMessages : BrokenRuleMessages
    {
        protected override void PopulateMessages()
        {
        }
    }
}
