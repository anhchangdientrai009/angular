﻿using System;

namespace SmartCA.Model.ChangeOrders
{
    public enum PriceChangeType
    {
        ContractSum, 
        GuaranteedMaximumPrice
    }
}
