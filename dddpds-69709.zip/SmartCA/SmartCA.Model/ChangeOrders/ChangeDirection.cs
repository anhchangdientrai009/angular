﻿using System;

namespace SmartCA.Model.ChangeOrders
{
    public enum ChangeDirection
    {
        Increased, 
        Decreased, 
        Unchanged
    }
}
