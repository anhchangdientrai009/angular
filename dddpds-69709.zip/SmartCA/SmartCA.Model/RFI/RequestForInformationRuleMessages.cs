﻿using System;
using SmartCA.Infrastructure.DomainBase;

namespace SmartCA.Model.RFI
{
    public class RequestForInformationRuleMessages : BrokenRuleMessages
    {
        protected override void PopulateMessages()
        {
        }
    }
}
