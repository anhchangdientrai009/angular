﻿using System;

namespace SmartCA.Model.NumberedProjectChildren
{
    internal static class NumberedProjectChildrenRuleMessageKeys
    {
        public const string InvalidNumber = "Invalid Number property value.";
    }
}
