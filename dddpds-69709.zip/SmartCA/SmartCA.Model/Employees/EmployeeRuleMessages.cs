﻿using System;
using SmartCA.Infrastructure.DomainBase;

namespace SmartCA.Model.Employees
{
    public class EmployeeRuleMessages : BrokenRuleMessages
    {
        protected override void PopulateMessages()
        {
        }
    }
}
